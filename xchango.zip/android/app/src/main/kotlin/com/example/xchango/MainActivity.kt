package com.example.xchango

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
